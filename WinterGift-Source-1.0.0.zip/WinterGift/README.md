# WinterGift v1.0.0

A simple `/gift` plugin for Minecraft Java servers running Paper or compatible Spigot/Bukkit APIs.

## Features
- `/gift` redeems the holiday reward.
- Sets the player's experience level to exactly level 10 (0% progress within level 10).
- Gives 64 diamonds.
- Sends the three requested colored messages.
- Each UUID can redeem once; claims are saved in `plugins/WinterGift/config.yml` and persist across restarts.
- If the inventory is full, any remaining diamonds are dropped at the player's location.

## Build
Requirements: JDK 21 and Maven 3.9+.

```bash
mvn clean package
```

The plugin JAR will be created at `target/WinterGift-1.0.0.jar`.

## Install
1. Build the project, or use a JAR built from this source.
2. Upload `WinterGift-1.0.0.jar` into the server's `plugins` folder.
3. Restart the server.
4. Join and run `/gift`.

## Compatibility
The project compiles against Paper API 1.21.11 and uses Bukkit API methods only. It is intended for Paper 1.21.11 and compatible Spigot builds. The `api-version` is `1.21`.

Minecraft 26.3 is a separate newer version line, not another spelling of 1.21.11. This project has not been built or tested against 26.3. For a 26.3 server, it should be recompiled against the matching 26.3 API and Java 25 after confirming the server software supports that release.
