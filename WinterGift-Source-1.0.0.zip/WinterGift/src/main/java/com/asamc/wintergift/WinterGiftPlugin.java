package com.asamc.wintergift;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class WinterGiftPlugin extends JavaPlugin implements CommandExecutor {
    private final Set<UUID> redeemedPlayers = new HashSet<>();

    @Override
    public void onEnable() {
        loadRedeemedPlayers();
        if (getCommand("gift") != null) {
            getCommand("gift").setExecutor(this);
        }
        getLogger().info("WinterGift v1.0.0 has been enabled!");
    }

    @Override
    public void onDisable() {
        saveRedeemedPlayers();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Only players can redeem this gift.");
            return true;
        }

        UUID playerId = player.getUniqueId();
        if (redeemedPlayers.contains(playerId)) {
            player.sendMessage(ChatColor.RED + "You have already claimed your WinterGift!");
            return true;
        }

        // Set the player's experience level to exactly level 10.
        player.setExp(0.0f);
        player.setLevel(10);

        // Give one full stack of diamonds. If the inventory is full, leftovers drop safely at the player's location.
        ItemStack diamonds = new ItemStack(Material.DIAMOND, 64);
        player.getInventory().addItem(diamonds).values()
                .forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));

        player.sendMessage(ChatColor.GREEN + "Yeayy!! you got a Holidays Gift");
        player.sendMessage(ChatColor.RED + "WinterGift");
        player.sendMessage(ChatColor.BLUE + "You Reached Level 7,and Get A 1x Stack Diamond For SurvivalSMP/War");

        redeemedPlayers.add(playerId);
        saveRedeemedPlayers();
        return true;
    }

    private void loadRedeemedPlayers() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().warning("Could not create plugin data folder.");
        }
        getConfig().options().copyDefaults(true);
        for (String rawId : getConfig().getStringList("redeemed-players")) {
            try {
                redeemedPlayers.add(UUID.fromString(rawId));
            } catch (IllegalArgumentException exception) {
                getLogger().warning("Ignoring invalid player UUID in config: " + rawId);
            }
        }
    }

    private void saveRedeemedPlayers() {
        getConfig().set("redeemed-players", redeemedPlayers.stream().map(UUID::toString).toList());
        saveConfig();
    }
}
